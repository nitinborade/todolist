<?php $__env->startSection('content'); ?>

   
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="submitauthor" method="POST" >
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" required>
                            <h3 class="text-center text-info">Add Item</h3>
                            <div class="form-group">
                                <label for="firstname" class="text-info">First Name:</label><br>
                                <input type="text" name="firstname" id="firstname" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="lastname" class="text-info">Last Name:</label><br>
                                <input type="text" name="lastname" id="lastname" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="dateofbirth" class="text-info">Date of Birth:</label><br>
                                <input type="text" name="dateofbirth" id="dateofbirth" class="form-control" required>
                            </div>

                              
                            <div class="form-group">
                                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                                  
                            
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

               
           

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>