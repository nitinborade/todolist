@extends('layouts.app')

@section('content')
<a class="btn btn-primary" href="home">Back</a>
<h2>Add Task</h2>
    <div class="container"> 
  {{session('msg')}} 
  <br>  
  <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="submititems" method="POST" >
                          <input type="hidden" name="_token" value="{{ csrf_token() }}" required>
                            
                            <div class="form-group">
                                <label for="items_name" class="text-info">Task Name:</label><br>
                                <input type="text" name="items_name" id="items_name" class="form-control" required> 
                            </div>
                             <div class="form-group">
                                <label for="user_name" class="text-info">User Name:</label><br>
                                <select class="form-control" id="user_name"  name="user_name">
                                    @foreach($userArr as $user)
                                    <option>{{$user->name}}</option>
                                   @endforeach
                                </select>
                                <input type="hidden" name="status" id="status" value="Pending..." class="form-control" required>
                            </div>

                            <div class="form-group">
                              
                               <input type="submit" name="submit" class="btn btn-primary" value="Add Item">   
                            
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>  
    <h2>Task List</h2>    
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Id</th>
        <th>Task Name</th>
        <th>User Name</th>
        <th>Status</th>
        <th>Action</th>
        
      </tr>
    </thead>
    <tbody>
        @foreach($todolistArr as $todolist)
      <tr>
        <td>{{$todolist->items_id}}</td>
        <td>{{$todolist->items_name}}</td>
        <td>{{$todolist->user_name}}</td>
        <td>{{$todolist->status}}</td>
       

        <td><a class="btn btn-primary" href="item_delete/{{$todolist->items_id}}">Delete</a> 
           &nbsp;&nbsp;<a class="btn btn-primary" href="item_edit/{{$todolist->items_id}}">Complete</a></td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>
<h2>User List</h2>
  <table class="table table-bordered">
    <thead>
      <tr>
        
        <th>User Name</th>
        <th>Email</th>
        <th>No of Task</th>
        
        
      </tr>
    </thead>
    <tbody>
        @foreach($userArr as $user)
      <tr>
        <td>{{$user->name}}</td>
        <td>{{$user->email}}</td>
        <td></td>
        
      </tr>
      @endforeach
    </tbody>
  </table>
@endsection