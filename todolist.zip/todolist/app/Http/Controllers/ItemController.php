<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Item;
use App\User;
use DB;

class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         return view('todolist');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
          $res1=new Item;
         $res1->items_name=$request->input('items_name');
         $res1->user_name=$request->input('user_name');
         $res1->status=$request->input('status'); 
         $res1->save(); 
         $request->session()->flash('msg','Task Added');
         return redirect('todolist');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Item $item,User $user)
    {
         return view('todolist')->with('todolistArr',Item::all())->with('userArr',User::all());
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $items_id)
    {
        

        $status="Complete";
        DB::update('update items set status= ? where items_id= ?',[$status,$items_id]);
         $request->session()->flash('msg','Task Complete');
         return redirect('todolist');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Item $item,Request $request,$items_id)
    {
         $column='items_id';
        $item= Item::where($column,'=',$items_id);
       $item->delete();
       $request->session()->flash('msg','Item Deleted');
       return redirect('todolist');
    }
}
